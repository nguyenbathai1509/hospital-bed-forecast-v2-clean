# V2-20 Streamlit Dashboard

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

V2-20 implements the Chapter 20 presentation layer from V2 MASTER. Streamlit is strictly a UI client of the already-verified V2-19 FastAPI backend. It does not connect to SQL Server and does not import Training, Forecast, Monitoring, Promotion, or Registry business services.

## Menu

- 🏠 Tổng quan
- 📂 Dữ liệu
- 🔮 Dự báo
- 🧠 Huấn luyện
- 📊 Kết quả Training
- 🏆 Model Registry
- 📈 Monitoring

## Architecture boundary

`Streamlit -> HTTP -> FastAPI -> verified service/repository -> SQL Server`

The UI must never bypass FastAPI. Exact confirmation phrases remain owned by the backend contracts and are only forwarded by the UI after explicit user input.

## Install

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-ui.txt
```

## Run

Terminal A:

```powershell
.\.venv\Scripts\python.exe -m scripts.run_api
```

Terminal B:

```powershell
.\.venv\Scripts\python.exe -m scripts.run_dashboard
```

Open `http://127.0.0.1:8501`.

Optional environment variables:

```text
V2_API_BASE_URL=http://127.0.0.1:8000
V2_UI_REQUEST_TIMEOUT_SECONDS=30
```

## Important lifecycle rules reflected by the UI

- Preview is visibly non-persisted, non-Official, and not Monitoring-eligible.
- Production Predict creates/reuses Draft only.
- Official requires exact `I_CONFIRM_OFFICIAL`.
- Recommended and Production are displayed as different states.
- Promotion requires exact `I_CONFIRM_PROMOTION` when V2-16 returns `CONFIRMATION_REQUIRED`.
- Emergency Rollback requires exact `I_CONFIRM_EMERGENCY_ROLLBACK` when a rollback target exists.
- Training uses asynchronous API jobs and polling; Streamlit never trains inside the UI process.
- Monitoring is Official-only and delegates manual/recovery runs to V2-18 through FastAPI.

## Chart limitation deliberately not fabricated

V2 MASTER asks for five principal Training charts. The current FastAPI Training Results endpoint exposes candidate metrics, per-department metrics, rankings, and recommendation, but not prediction-by-date evaluation rows. Therefore V2-20 can correctly render MAE Model Comparison and MAE by Department now. Train/Test Timeline, Actual vs Predicted Test, and Residual over Time require a future read-only chart-dataset API; the UI explicitly states this rather than reconstructing or fabricating evaluation predictions.

## Current deployment boundary

Roles/Permissions are not implemented yet. Keep FastAPI and Streamlit on local/internal addresses only until the Scheduler + Roles phase is completed.
