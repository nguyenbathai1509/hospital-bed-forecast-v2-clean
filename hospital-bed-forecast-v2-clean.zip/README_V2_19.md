# V2-19 - FastAPI and API Contract

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

## Part A - API Foundation + Data Status — COMPLETE

Verified on the user's Windows environment:

- FastAPI 0.141.1
- Uvicorn 0.52.4
- Pydantic 2.13.5
- HTTPX 0.28.1
- 54/54 tests PASS
- `GET /health` -> 200
- `GET /data/status` -> 200 against real SQL Server
- `GET /departments` -> 200 against real SQL Server
- Vietnamese Unicode verified from Python HTTPX; the earlier mojibake was only PowerShell console rendering.

## Part B - Pipeline/Data API

Part B implements the remaining Master V2 section 19.2 endpoints:

- `GET /pipeline/runs` - Daily Pipeline history with quality summary.
- `POST /pipeline/run` - manual trigger delegating to the existing Daily Pipeline service.
- `GET /data-quality` - DQ issues by run/date/department/severity.
- `GET /history` - CLEAN occupancy and patient-flow history by department.

Architectural rules:

- FastAPI does not reimplement RAW/DQ/CLEAN/FEATURE/ML/Monitoring logic.
- `POST /pipeline/run` delegates to `run_daily_excel_pipeline` through a dependency.
- The endpoint does not accept arbitrary filesystem paths. Under current `EXCEL_BOOTSTRAP` it resolves the verified project paths `data/HSNoi.xlsx` and `data/hsNgoai.xlsx` internally. A future Hospital SQL source adapter can replace the dependency without changing the route contract.
- `GET /data-quality` defaults to the latest pipeline run, while an explicit unknown run returns HTTP 404.
- `GET /history` reads `dbo.clean_bed_daily`, not RAW, and returns occupancy, flows, derived `net_flow`, utilization, quality flag and source revision.
- Invalid request schemas return 422; invalid date ranges return 400; missing department/run resources return 404.
- Authorization for the manual pipeline trigger is still a required deployment gate and will be enforced in the later Roles/Permissions phase. Until that phase, the API is local/internal only and must not be exposed publicly.

Part B code-ready snapshot: **65/65 tests PASS** in the prepared snapshot. User-side unit verification and SQL/API runtime integration remain pending.

## User unit-test verification

On the user's Windows environment, the full suite passed: **65 passed, 2 warnings in 2.60s**. The warnings are the existing Starlette/FastAPI TestClient and anyio deprecations; they are non-blocking. Runtime SQL/API verification remains pending.

## Part B runtime read checkpoint — VERIFIED

User-side Windows + SQL Server verification:

- Full test suite: 65 passed, 2 deprecation warnings.
- `GET /pipeline/runs?limit=5` -> HTTP 200. Latest run `DAY_20260907T170849Z_7E731C5C` is `DATA_READY`, business date 2026-06-30, rows=362, DQ ERROR=0/WARNING=0/CHECK=2. Historical runs remain visible, including an older run with WARNING=231.
- `GET /data-quality?severity=CHECK&limit=10` -> HTTP 200, exactly 2 current CHECK rows, both rule `DQ07`, for department 343 on 2026-03-20 (-1 balance difference) and 2026-03-21 (+1 balance difference).
- `GET /history?department_id=343&start_date=2026-06-28&end_date=2026-06-30` -> HTTP 200, exactly 3 CLEAN rows. Occupied beds: 42, 44, 40; net flow: -7, +2, -4; quality=PASS; source_revision_no=1.
- Vietnamese mojibake seen in PowerShell is console rendering only; Part A already verified the HTTP JSON Unicode is correct with Python HTTPX.

Conclusion: Part B read-only runtime integration is verified. `POST /pipeline/run` runtime verification is still pending before Part B can be marked complete.

## Part B runtime write/orchestration checkpoint — VERIFIED

User-side Windows + SQL Server verification:

- `POST /pipeline/run` -> HTTP 200 through FastAPI/Uvicorn.
- New run: `DAY_20260908T005428Z_CC275B88`, status `DATA_READY`, business date 2026-06-30, rows=362, data/feature versions unchanged.
- DQ remains ERROR=0/WARNING=0/CHECK=2.
- RAW inserted=0, updated=0, unchanged=362; CLEAN=362; FEATURE=362; H1 samples=354; H3 samples=350.
- Production-cycle activation PASS with 0 activations.
- Actual Matching remains `WAITING_FOR_ACTUAL`: Official=4, matched=0, waiting=4, missing=0.
- Monitoring snapshot `MON_DAY_20260908T005428Z_CC275B88` is linked to the new pipeline run and remains `WAITING_FOR_ACTUAL`, with metric_row_count=0 and no fabricated metrics.

Conclusion: Part B write/orchestration runtime integration is verified. Final regression checks for V2-12, V2-17 and V2-18 remain before marking Part B complete.

## Part B final regression — COMPLETE

Final user-side regression on Windows after the real FastAPI-triggered Daily Pipeline run:

- `GET /pipeline/runs?limit=1` returned the new run `DAY_20260908T005428Z_CC275B88` as the latest run, status `DATA_READY`, 362 extracted rows, DQ ERROR=0/WARNING=0/CHECK=2.
- Full test suite remained green: **65 passed, 2 warnings in 2.75s**. The two warnings are the same non-blocking Starlette/FastAPI TestClient and anyio deprecations already recorded in Part A/B.
- `scripts.verify_v2_12` -> **PASS**. Latest run is `DAY_20260908T005428Z_CC275B88`; feature rows=362, full-lag3 rows=356, ML samples=704, RAW revisions >1 = 0, DQ=0/0/2.
- `scripts.verify_v2_17` -> **PASS**. Drafts=4, open drafts=0, Officials=4, duplicate Official keys=0, daily model locks=2, lock/target/value contracts all true.
- `scripts.verify_v2_18` -> **PASS**. Latest pipeline and monitoring snapshot are linked to the new run; Official=4, Actual available=0, matched=0, waiting=4, missing=0, metric rows=0, with no fabricated Actual or monitoring metrics.

**V2-19 Part B status: COMPLETE.** Pipeline/Data API now has verified unit contracts, real SQL read integration, real FastAPI write/orchestration integration, and regression protection for V2-12/V2-17/V2-18.

Next Master V2 section is **19.3 Training/Model API**: asynchronous training start/status/results/history plus registry/production/promotion/rollback endpoints. The API layer must continue delegating to the verified V2-13..V2-16 services and must not duplicate their business rules.

## Part C1 - Asynchronous Training API + Persistent Job Runner

Part C1 implements the four Training endpoints from the V2 FastAPI contract:

- `POST /training/start`
- `GET /training/status/{job_id}`
- `GET /training/runs`
- `GET /training/results/{run_id}`

The central architectural rule is that model training must not run inside the HTTP
request. `POST /training/start` creates or reuses a persistent row in
`dbo.api_training_jobs`, returns HTTP 202 with a `job_id`, and launches a fixed worker
command using the same Python virtual environment. The worker then delegates all
scientific work to the already verified V2-14 `run_training()` service and V2-15
`generate_recommendations()` service.

Migration `008_api_training_jobs.sql` adds only API orchestration state. It does not
replace `dbo.training_runs`: `dbo.training_runs` remains the scientific/audit Training
Run and still enforces at most one COMPLETED Training Run per `business_date`.

Job statuses are `PENDING`, `RUNNING`, `COMPLETED`, and `FAILED`. PENDING/RUNNING jobs
for the same business date are reused, as is a completed API job linked to a still
COMPLETED Training Run. FAILED jobs are not reused, which preserves the V2 Retry rule.
The job stores lineage to the source DATA_READY pipeline run and, after success, to the
scientific Training Run.

The worker is launched as:

`<same-python> -m scripts.run_training_job --job-id <job_id>`

No executable path, Python module, artifact location, or filesystem path is accepted
from the HTTP client. This keeps the worker launch contract closed and auditable.

`GET /training/results/{run_id}` exposes overall candidate metrics, mandatory
per-department metrics, immutable recommendation snapshots, and ranking snapshots.
Recommended remains different from Production; Part C1 does not write
`dbo.production_models`.

Prepared code snapshot: **77/77 tests PASS** (65 prior tests + 12 Part C1 tests).
SQL migration/runtime verification on the user's Windows + SQL Server environment is
still pending, so Part C1 is CODE-READY rather than COMPLETE.

## Part C1 user unit + SQL migration checkpoint — VERIFIED

User-side Windows verification on 2026-09-08:

- Full suite: **77 passed, 2 warnings in 3.10s**. The warnings are the existing non-blocking Starlette/FastAPI TestClient and anyio deprecations.
- `scripts.setup_db` run 1: migrations 001-007 skipped as already applied; `008_api_training_jobs.sql` applied successfully; migrations completed.
- `scripts.setup_db` run 2: migrations 001-008 all skipped as already applied, proving migration 008 is idempotent.
- No database reset and no V2-11..V2-18 schema rewrite was needed.

**Part C1 status: UNIT-TEST VERIFIED + SQL MIGRATION VERIFIED, PENDING ASYNC RUNTIME.** The remaining checkpoint is the real Uvicorn flow `POST /training/start` -> poll `/training/status/{job_id}` -> read `/training/results/{run_id}`. Because business date 2026-06-30 already has a COMPLETED V2-14 Training Run and V2-15 recommendation snapshot, the worker is expected to reuse `ALREADY_COMPLETED` / `ALREADY_RECOMMENDED` rather than retrain eight models.

## Part C1 asynchronous runtime checkpoint — VERIFIED, reuse check pending

User-side Uvicorn + SQL Server verification on 2026-09-08:

- `GET /training/runs?limit=3` -> HTTP 200 and returned the existing scientific Training Run `TRN_20260907T105913Z_686E6A0C`, business_date 2026-06-30, status COMPLETED, row_count=704, department_count=2, random_seed=42, completed_candidate_count=8.
- `POST /training/start` -> HTTP 202 Accepted and created persistent job `TJOB_20260908T041159Z_AD19E47E`, status PENDING, source pipeline `DAY_20260908T005428Z_CC275B88`, reused=false.
- Detached worker claimed and completed the job quickly. `GET /training/status/TJOB_20260908T041159Z_AD19E47E` -> COMPLETED, linked to the existing Training Run `TRN_20260907T105913Z_686E6A0C`, error_message=null.
- `GET /training/results/TRN_20260907T105913Z_686E6A0C` -> candidate_count=8, department_metric_count=16, recommendation_count=2, ranking_count=8.
- H1 recommendation remains RF/KEEP although SVR is best on MAE; guardrail_pass=false, reason KEEP_THRESHOLD_AND_GUARDRAIL. H3 remains SVR/KEEP with guardrail_pass=true, reason BEST_IS_CHAMPION.
- Recommended remains separate from Production; Part C1 does not write `dbo.production_models`.

This verifies the real HTTP 202 -> persistent SQL job -> detached worker -> V2-14 Training Service -> V2-15 Recommendation -> polling/results flow. Because the business date already had a COMPLETED scientific Training Run, the worker reused it rather than retraining eight models.

**Part C1 status: ASYNC RUNTIME VERIFIED, PENDING FINAL REUSE/IDEMPOTENCY CHECK.** A second `POST /training/start` for the same business date must reuse `TJOB_20260908T041159Z_AD19E47E` with `reused=true` and must not create/launch a second job.

## Part C1 reuse/idempotency runtime checkpoint — VERIFIED

A second real `POST /training/start` was executed for the same `business_date=2026-06-30` after the first API Training Job had already completed.

- The API returned HTTP 202 with the same persistent job `TJOB_20260908T041159Z_AD19E47E` and `reused=true`.
- The response remained linked to source pipeline `DAY_20260908T005428Z_CC275B88` and scientific Training Run `TRN_20260907T105913Z_686E6A0C`.
- `same_job_id=true`; no second TJOB was created.
- After an additional two-second wait, `created_at`, `started_at`, and `completed_at` were all unchanged, proving the completed job was not claimed again and the worker was not relaunched.
- Final status remained `COMPLETED`, `error_message=null`, and the scientific Training Run id remained unchanged.

This verifies the runtime reuse/idempotency contract for the asynchronous Training API. **Part C1 is still pending only the final regression suite before being marked COMPLETE.**


## Part C1 final regression compatibility fix — CODE-READY, rerun pending

The first final regression after Part C1 produced `V2-14 VERIFY: FAIL` and `V2-15 VERIFY: FAIL` even though their scientific/training/recommendation contracts remained intact. The reports showed `active_production_count=2`, which is the valid downstream state created by the already-verified V2-16 Production Promotion step (H1 RF and H3 SVR are ACTIVE).

The cause was a stale stage-local verifier assumption left from the original V2-14/V2-15 checkpoints: both scripts still required `active_production_count == 0`. That was correct only before V2-16 existed, but it is no longer a valid regression condition after Promotion. Active Production is downstream state and must not make the immutable V2-14 Training or V2-15 Recommendation snapshots fail.

Fix: remove only the obsolete `active_production_count == 0` gate from `scripts/verify_v2_14.py` and `scripts/verify_v2_15.py`. The count remains in both JSON reports as informational evidence. No Training, Recommendation, Production, Official, Monitoring, SQL schema, model artifact, or database row is modified.

Expected rerun: V2-14 PASS and V2-15 PASS with `active_production_count=2`; V2-12/V2-17/V2-18 remain PASS. Part C1 remains pending until that rerun is verified.

## Part C1 final regression — VERIFIED, COMPLETE

Final user-side rerun after the verifier compatibility fix:

- Full suite: **77 passed, 2 warnings in 2.99s**. The warnings are the same non-blocking FastAPI/Starlette TestClient and anyio deprecations.
- `scripts.verify_v2_14` -> **PASS** with `active_production_count=2`. Scientific Training evidence remains intact: run `TRN_20260907T105913Z_686E6A0C`, row_count=704, department_count=2, completed_candidate_count=8, 8 candidates, 16 per-department metric rows, no artifact-integrity errors.
- `scripts.verify_v2_15` -> **PASS** with `active_production_count=2`. Recommendation snapshot remains H1 RF/KEEP (best MAE candidate SVR, guardrail/threshold keep) and H3 SVR/KEEP; 2 recommendations, 8 rankings, 2 recommended flags.
- `scripts.verify_v2_12` -> **PASS**. Latest pipeline remains `DAY_20260908T005428Z_CC275B88`, DATA_READY, rows_extracted=362, DQ=0/0/2.
- `scripts.verify_v2_17` -> **PASS**. Officials=4, duplicate keys=0, daily model locks=2, lock/target/value contracts true.
- `scripts.verify_v2_18` -> **PASS**. Monitoring run `MON_DAY_20260908T005428Z_CC275B88` remains WAITING_FOR_ACTUAL with Official=4, matched=0, waiting=4, missing=0, metric rows=0.

The verifier change is lifecycle compatibility, not a relaxation of scientific criteria: only the stale pre-V2-16 assumption `active_production_count == 0` was removed from V2-14/V2-15 PASS gates. The count remains reported for downstream observability.

**V2-19 Part C1 status: COMPLETE.** Async Training API, persistent SQL job orchestration, detached worker, training-run/recommendation reuse, result read models, second-POST idempotency, and final regression are all verified on Windows + SQL Server.

Next: **V2-19 Part C2 — Model Registry / Production / Promotion / Rollback API**. FastAPI must continue delegating to the verified V2-13/V2-16 services and must not duplicate promotion, confirmation, daily-lock, rollback, or audit business rules.

## Part C2 - Model Registry / Production / Promotion / Rollback API — CODE-READY

Part C2 adds the remaining four Model endpoints from Master V2 section 19.3:

- `GET /models`
- `GET /models/production`
- `POST /models/promote`
- `POST /models/rollback`

The read endpoints expose Model Registry metrics/status and the current Production state,
including ACTIVE/SCHEDULED slots, the latest recommendation, the latest DATA_READY
business date, the normal Production Change quota state, and any daily model lock for
that business date. Internal model artifact filesystem paths and SHA-256 values are not
exposed through `GET /models`; artifact integrity remains a backend registry concern.

The write endpoints do not reimplement Promotion or Rollback rules. A thin
`ModelCommandService` delegates directly to the already-verified V2-16
`execute_promotion()` and `execute_emergency_rollback()` services. Their exact explicit
confirmation phrases, normal daily quota, IMMEDIATE/NEXT_CYCLE decision, daily-lock
checks, transactional audit trail, rollback target resolution, and Official-history
immutability therefore remain owned by V2-16.

HTTP mapping is intentionally thin: V2-16 `ValueError` becomes HTTP 400 and V2-16
`RuntimeError` becomes HTTP 409. Normal service results `NO_CHANGE`,
`CONFIRMATION_REQUIRED`, and `COMPLETED` remain HTTP 200 response states so clients can
review the service-generated plan before sending the exact confirmation phrase.

The current verified database is expected to make a real `/models/promote` call without
confirmation return `NO_CHANGE`, because H1 RF and H3 SVR are already both Recommended
and ACTIVE Production. A real `/models/rollback` preview is expected to return HTTP 409
at the current state because the initial Production promotion had no previous RETIRED
candidate to roll back to. These are safe no-mutation runtime checks.

Part C2 also updates `scripts/verify_v2_16.py` for downstream lifecycle compatibility:
`daily_model_lock_count` remains reported, but it is no longer required to equal zero.
Zero locks was only the original pre-V2-17 checkpoint state; after Official confirmation,
V2-17 correctly creates daily model locks. All original V2-16 Promotion evidence and
normal-change quota checks remain in the verifier.

Prepared snapshot: **92/92 tests PASS** (77 prior + 15 Part C2 tests). No new SQL
migration and no dependency change are required. User-side Uvicorn + SQL runtime checks
remain pending, so Part C2 is CODE-READY rather than COMPLETE.

## Part C2 - FINAL VERIFIED

User-side verification on Windows + SQL Server completed successfully. Final evidence:

- `pytest -q`: **92 passed, 2 warnings**. The two warnings remain the known FastAPI/Starlette TestClient and anyio deprecations and are not runtime failures.
- `scripts.verify_v2_16`: **PASS**. One committed NORMAL_PROMOTION exists for business date 2026-06-30, with 2 change items; ACTIVE Production remains H1 RF + H3 SVR; scheduled slots=0; daily model locks=2; normal-change quota count=1 and unique quota index is present.
- `scripts.verify_v2_15`: **PASS**. Two recommendation snapshots and eight ranking rows remain intact; H1 Recommended RF/KEEP, H3 Recommended SVR/KEEP.
- `scripts.verify_v2_17`: **PASS**. Four confirmed Drafts/Official forecasts remain immutable, duplicate Official keys=0, daily model locks=2 and Official lock/target/value contracts remain valid.
- `scripts.verify_v2_12`: **PASS**. Latest pipeline `DAY_20260908T005428Z_CC275B88` remains DATA_READY with 362 rows and DQ ERROR=0/WARNING=0/CHECK=2.
- `scripts.verify_v2_18`: **PASS**. Monitoring run `MON_DAY_20260908T005428Z_CC275B88` remains WAITING_FOR_ACTUAL with Official=4, matched=0, waiting=4, missing=0, metric rows=0.

Real command runtime was also verified without mutating Production:

- `POST /models/promote` without confirmation returned HTTP 200 `NO_CHANGE`, because Recommended H1 RF and H3 SVR are already ACTIVE Production. No new change transaction was created.
- `POST /models/rollback` without confirmation returned HTTP 409 `MODEL_ROLLBACK_CONFLICT`, because no previous RETIRED Production candidate exists yet for H1.
- A subsequent `GET /models/production` proved Production remained unchanged: H1 RF, H3 SVR, no scheduled slots, the same two daily locks, and normal-change quota already used exactly once.

**V2-19 Part C2 status: COMPLETE / FINAL VERIFIED.** FastAPI exposes Model Registry and Production read models and delegates Promotion/Rollback commands to the verified V2-16 service layer without duplicating business rules. The next lifecycle slice is **V2-19 Part D - Forecast Lifecycle + Monitoring API**.


## V2-19 Part D - Forecast Lifecycle + Monitoring API (CODE-READY)

Part D exposes the already verified V2-17/V2-18 lifecycle through FastAPI without
reimplementing business rules. Preview remains non-persisted/non-Official; Production
Predict creates/reuses Draft only; only the exact `I_CONFIRM_OFFICIAL` phrase can move
open Drafts to immutable Official Forecasts; Monitoring is Official-only evidence.

Endpoints:
- `POST /forecasts/preview`
- `POST /forecasts/production`
- `GET /forecasts/drafts`
- `POST /forecasts/official/confirm`
- `GET /forecasts/official`
- `GET /monitoring`
- `POST /monitoring/run`

`/monitoring/run` is a local/internal recovery/manual trigger until Roles/Permissions is
implemented. Daily Pipeline behavior is unchanged and still owns the normal daily
Actual Matching + Monitoring stage. No SQL migration or dependency change is required.

Code-ready checkpoint: 107 tests pass in the prepared snapshot. Runtime verification
against the user's SQL Server is still required before Part D can be marked COMPLETE.
