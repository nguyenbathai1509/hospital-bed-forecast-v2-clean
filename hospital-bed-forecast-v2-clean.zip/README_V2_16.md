# V2-16 - Production Promotion + Rollback

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

This phase adds the governed boundary between Recommendation and Production.

Key contracts:
- Recommended is advisory; only confirmed Promotion changes Production.
- One normal Production Change Transaction per business_date.
- If no daily model lock exists for a horizon, effect is IMMEDIATE.
- If a daily model lock exists, effect is NEXT_CYCLE.
- Emergency rollback is an audited quota exception with a stronger confirmation phrase.
- Rollback never rewrites historical Official Forecasts.
- Daily Pipeline activates due NEXT_CYCLE slots only when that business_date+horizon is not locked.

Initial bootstrap on the verified thesis dataset should activate Recommended RF for H+1 and Recommended SVR for H+3 in one confirmed IMMEDIATE transaction.
