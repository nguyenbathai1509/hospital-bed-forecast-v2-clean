# Dự báo giường bệnh V2

Ứng dụng xử lý dữ liệu giường bệnh, huấn luyện và đánh giá mô hình, quản lý mô hình sử dụng, lập dự báo và đối chiếu với thực tế. Kiến trúc: **Streamlit → FastAPI → services/repositories → SQL Server**.

Nguồn hiện tại là hai file Excel `data/HSNoi.xlsx` và `data/hsNgoai.xlsx`, chưa phải kết nối trực tiếp HIS. Mô hình gồm RF, XGBoost, SVR và LSTM cho H+1/H+3; chỉ số đánh giá chính là MAE.

## Bắt đầu

- [Cài đặt và chạy trên Windows](docs/WINDOWS_QUICKSTART.md): môi trường, cấu hình, database, API và giao diện.
- [Quy trình vận hành](docs/OPERATIONS.md): thêm dữ liệu, huấn luyện, chọn mô hình, xác nhận dự báo và xử lý sự cố.
- [Kết quả nghiệm thu backend thật](docs/E2E_ACCEPTANCE.md): bằng chứng, môi trường cách ly và phạm vi chưa kiểm chứng.

Nếu đã cài đủ thư viện và cấu hình database, chạy từ thư mục gốc project trong **hai terminal PowerShell riêng**:

```powershell
# Terminal 1: backend
.venv\Scripts\python.exe -m scripts.run_api
```

```powershell
# Terminal 2: giao diện
$env:V2_API_BASE_URL = 'http://127.0.0.1:8000'
.venv\Scripts\python.exe -m scripts.run_dashboard
```

Mở giao diện tại `http://127.0.0.1:8501`. Backend đọc `.env`; cấu hình giao diện đọc biến môi trường của terminal, không tự nạp `.env`.

## Luồng sử dụng

```text
Excel mới → Chạy pipeline → Kiểm tra chất lượng và DATA_READY
                               ↓
                 Huấn luyện → Đánh giá → Chọn mô hình sử dụng
                                             ↓
                    Xem thử → Bản nháp → Xác nhận chính thức
                                             ↓
                   Dữ liệu thực tế mới → Đối chiếu và giám sát
```

Giao diện có tám trang: Tổng quan, Dữ liệu, Huấn luyện mô hình, Kết quả huấn luyện, Quản lý mô hình, Dự báo, Giám sát và Đặt lại trình diễn. Trang đặt lại không thuộc quy trình vận hành thông thường.

Thêm file/dòng Excel **không tự chạy pipeline hoặc huấn luyện**. Pipeline không tự tạo dự báo chính thức; người dùng phải kiểm tra và xác nhận. Không nhất thiết huấn luyện lại mỗi lần thêm ngày nếu mô hình đang sử dụng vẫn phù hợp.

## Lưu ý an toàn

- Phân quyền đang được bỏ qua theo phạm vi dự án: chỉ dùng cục bộ hoặc trong môi trường nội bộ được kiểm soát, không mở trực tiếp ra Internet.
- Không đưa `.env`, mật khẩu, dữ liệu bệnh viện hoặc artifact/bằng chứng chứa dữ liệu nhạy cảm lên dịch vụ công khai.
- Database `HospitalBedForecastV2_E2E` chứa dữ liệu thử; không dùng làm database vận hành.
- Timeout giao diện không chứng minh thao tác backend đã thất bại. Kiểm tra trạng thái/lịch sử trước khi gửi lại thao tác ghi.
- Khoảng dự báo tham khảo không bảo đảm mức bao phủ trên dữ liệu tương lai; nghiệm thu kỹ thuật không chứng nhận chất lượng sử dụng lâm sàng.

## Kiểm thử và tài liệu kỹ thuật

```powershell
.venv\Scripts\python.exe -m pytest -q
```

Kiểm thử SQL tùy chọn cần bật riêng; công cụ E2E có thao tác ghi vào môi trường thử và không chạy trong bộ pytest mặc định. Xem hướng dẫn tương ứng trước khi chạy.

| Chủ đề | Tài liệu |
| --- | --- |
| Chia tập theo dữ liệu mới | [Dynamic training split](docs/DYNAMIC_TRAINING_SPLIT.md) |
| So sánh trên cùng cửa sổ | [Common-window backtest](docs/COMMON_WINDOW_BACKTEST.md) |
| Baseline và khoảng dự báo | [Baselines and uncertainty](docs/BASELINES_AND_UNCERTAINTY.md) |
| Worker và khôi phục tác vụ | [Training job recovery](docs/TRAINING_JOB_RECOVERY.md) |
| Giao diện và CSS | [Visual system](docs/UI_VISUAL_SYSTEM.md) |
| Quy trình giao diện | [Workflow review](docs/UI_WORKFLOW_REVIEW.md) |
| Hiệu năng giao diện | [UI performance](docs/UI_PERFORMANCE.md) |

Các file `README_V2_*` và tài liệu `V2-11_*` là hồ sơ từng giai đoạn. Mốc ngày, số dòng và giới hạn trong đó không mặc nhiên mô tả phiên bản hiện tại; dùng hai hướng dẫn vận hành ở đầu trang cho công việc hằng ngày.
