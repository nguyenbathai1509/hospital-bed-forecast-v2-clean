# V2-18 - Actual Matching + Production Monitoring

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

## Part A - Monitoring Core

Part A defines the pure contracts before SQL persistence.

Key rules:
- Only Official Forecast is eligible for Actual Matching and Production Monitoring.
- If target_date is later than the latest CLEAN Actual date for that department, status is `WAITING_FOR_ACTUAL`; future Actual is never fabricated.
- Error sign is `actual - prediction`; positive error/bias means underprediction.
- Primary Production metrics use `prediction_raw` so they remain comparable with V2-09/V2-14 evaluation metrics.
- `prediction_rounded` remains operational evidence and does not replace raw model-quality metrics.

User verification: 43/43 tests PASS.

## Part B - SQL Persistence + Daily Pipeline Integration

Part B adds:
- `migrations/007_actual_matching_monitoring.sql`
- `dbo.official_actual_matches`
- `dbo.production_monitoring_runs`
- `dbo.production_monitoring_metrics`
- `src/monitoring/repository.py`
- `src/monitoring/service.py`
- `scripts/run_monitoring.py`
- `scripts/verify_v2_18.py`
- Daily Pipeline stages `ACTUAL_MATCHING` and `MONITORING`

The match table is keyed by `official_id`, therefore Preview, Draft, Recommended and Custom forecasts cannot become Production monitoring evidence.

If CLEAN Actual is corrected later, the current match evidence is refreshed only when the actual value/quality/source revision changes; `match_revision_no` increments. Monitoring snapshots are attached to the Daily Pipeline run and remain auditable.

Capacity alert monitoring is connected here without changing the forecasting rule: `planned_beds` is still only a capacity reference, never a prediction cap. Actual capacity event is `actual_occupied_beds > planned_beds`; the Official `capacity_alert` is evaluated via TP/FP/FN/TN, precision, recall and accuracy.

With the current verified bootstrap dataset:
- latest CLEAN Actual = 2026-06-30
- Official H+1 target = 2026-07-01
- Official H+3 target = 2026-07-03

Therefore the scientifically correct initial integration result is 4 Official rows waiting for Actual, 0 matched rows and 0 monitoring metric rows. No future Actual is invented.

Part B internal code-ready snapshot: **48/48 tests PASS**. SQL integration remains pending until migration 007 and the updated Daily Pipeline are run on the user's SQL Server.
