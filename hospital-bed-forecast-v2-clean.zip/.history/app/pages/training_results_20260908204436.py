from __future__ import annotations

from datetime import timedelta

import altair as alt
import pandas as pd
import streamlit as st

from app.api_client import ApiClientError, HospitalApiClient
from app.components import dataframe, page_header, show_api_error
from app.viewmodels import (
    TRAINING_METRICS,
    candidate_rows_for_horizon,
    enrich_department_metrics,
    evaluation_chart_frame,
    metric_comparison_rows,
)


def _timeline_chart(split: dict) -> alt.Chart:
    rows = [
        {
            "phase": "Train",
            "start": pd.to_datetime(split.get("train_start")),
            "end": pd.to_datetime(split.get("train_end")) + timedelta(days=1),
        },
        {
            "phase": "Validation",
            "start": pd.to_datetime(split.get("validation_start")),
            "end": pd.to_datetime(split.get("validation_end")) + timedelta(days=1),
        },
        {
            "phase": "Test",
            "start": pd.to_datetime(split.get("test_start")),
            "end": pd.to_datetime(split.get("test_end")) + timedelta(days=1),
        },
    ]
    frame = pd.DataFrame(rows).dropna()
    return (
        alt.Chart(frame)
        .mark_bar(size=28)
        .encode(
            x=alt.X("start:T", title="Thời gian"),
            x2="end:T",
            y=alt.Y(
                "phase:N",
                title=None,
                sort=["Train", "Validation", "Test"],
            ),
            tooltip=[
                alt.Tooltip("phase:N", title="Giai đoạn"),
                alt.Tooltip("start:T", title="Bắt đầu"),
                alt.Tooltip("end:T", title="Kết thúc hiển thị"),
            ],
        )
        .properties(height=150)
    )


def _metric_help(meta: dict) -> str:
    better = meta.get("better")
    if better == "lower":
        return "Càng thấp càng tốt."
    if better == "higher":
        return "Càng cao càng tốt."
    return "Bias càng gần 0 càng tốt."


def render(client: HospitalApiClient) -> None:
    page_header(
        "📊 Kết quả Training",
        "Toàn bộ biểu đồ và metric đọc theo Training Run; mặc định chọn run COMPLETED mới nhất và vẫn cho phép xem lại lịch sử.",
    )

    try:
        runs = client.training_runs(status="COMPLETED", limit=50).get("rows", [])
        departments = client.departments()
    except ApiClientError as exc:
        show_api_error(exc)
        return

    if not runs:
        st.info("Chưa có COMPLETED Training Run.")
        return

    labels = {
        f"{row['business_date']} | {row['run_id']}": row["run_id"]
        for row in runs
    }
    selected = st.selectbox("Training Run", list(labels))
    run_id = labels[selected]

    try:
        result = client.training_results(run_id)
    except ApiClientError as exc:
        show_api_error(exc)
        return

    run = result.get("run", {})
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Samples", run.get("row_count") or "-")
    c2.metric("Khoa", run.get("department_count") or "-")
    c3.metric("Candidates", run.get("completed_candidate_count") or "-")
    c4.metric("Feature version", run.get("feature_version") or "-")

    recommendations = result.get("recommendations", [])
    st.subheader("Recommendation")
    dataframe(recommendations, height=220)

    horizon = st.radio(
        "Horizon phân tích",
        [1, 3],
        horizontal=True,
        format_func=lambda h: f"H+{h}",
    )

    candidates_all = result.get("candidates", [])
    candidates = candidate_rows_for_horizon(candidates_all, horizon)
    enriched_department_metrics = enrich_department_metrics(
        result.get("department_metrics", []),
        candidates_all,
    )

    st.subheader("So sánh metric giữa các model")
    metric_name = st.selectbox("Metric", list(TRAINING_METRICS))
    metric_meta = TRAINING_METRICS[metric_name]
    metric_key = str(metric_meta["key"])
    scale = float(metric_meta.get("scale", 1.0))
    unit = str(metric_meta.get("unit") or "")

    scope_options = {"Toàn bộ (Global)": None}
    for dept in departments:
        scope_options[
            f"Khoa {dept['department_id']} - {dept['department_name']}"
        ] = int(dept["department_id"])
    scope_label = st.selectbox("Phạm vi metric", list(scope_options))
    metric_department_id = scope_options[scope_label]

    metric_source = (
        candidates_all
        if metric_department_id is None
        else enriched_department_metrics
    )
    metric_rows = metric_comparison_rows(
        metric_source,
        horizon=horizon,
        metric_key=metric_key,
        department_id=metric_department_id,
    )
    if metric_rows:
        chart_df = pd.DataFrame(metric_rows)
        chart_df["value"] = chart_df["value"].astype(float) * scale
        chart_df = chart_df.set_index("model_family")
        st.bar_chart(chart_df[["value"]])
        st.caption(
            f"{metric_name} ({unit or 'unitless'}). {_metric_help(metric_meta)}"
        )
    else:
        st.info("Không có metric phù hợp với lựa chọn hiện tại.")

    with st.expander("Bảng metric Global"):
        dataframe(candidates, height=280)

    with st.expander("Bảng metric theo khoa"):
        dataframe(
            [
                row
                for row in enriched_department_metrics
                if int(row.get("horizon") or 0) == horizon
            ],
            height=320,
        )

    st.divider()
    st.subheader("Evaluation TEST – biểu đồ theo từng ngày")

    model_families = [
        str(row["model_family"])
        for row in candidates
        if row.get("model_family")
    ]
    if not model_families:
        st.info("Training Run chưa có candidates cho horizon này.")
        return

    evaluation_model = st.selectbox(
        "Model cho biểu đồ TEST",
        model_families,
    )
    department_map = {
        f"{row['department_id']} - {row['department_name']}": int(row["department_id"])
        for row in departments
    }
    evaluation_department_label = st.selectbox(
        "Khoa cho biểu đồ TEST",
        list(department_map),
    )
    evaluation_department_id = department_map[evaluation_department_label]

    try:
        evaluation = client.training_evaluation(
            run_id=run_id,
            horizon=horizon,
            model_family=evaluation_model,
            department_id=evaluation_department_id,
        )
    except ApiClientError as exc:
        show_api_error(exc)
        return

    split = evaluation.get("split", {})
    rows = evaluation.get("rows", [])

    st.markdown("#### 1. Train / Validation / Test Timeline")
    st.altair_chart(
        _timeline_chart(split),
        use_container_width=True,
    )
    st.caption(
        "Split theo target_date, shuffle=false. Test giữ nguyên là holdout lịch sử; biểu đồ không dùng Production artifact để dự báo ngược Test Set."
    )

    chart_rows = evaluation_chart_frame(rows)
    if chart_rows:
        frame = pd.DataFrame(chart_rows)
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frame = frame.sort_values("target_date").set_index("target_date")

        st.markdown("#### 2. Actual vs Predicted – Test Set")
        st.line_chart(frame[["actual", "predicted"]])

        st.markdown("#### 3. Residual over Time")
        st.line_chart(frame[["residual", "zero"]])
        st.caption(
            "Residual = Actual - Predicted. Residual > 0 nghĩa là model dự báo thấp hơn thực tế (underprediction); Residual < 0 nghĩa là dự báo cao hơn thực tế."
        )
    else:
        st.info("Không có row-level TEST predictions cho lựa chọn hiện tại.")

    st.markdown("#### Ranking")
    dataframe(
        [
            row
            for row in result.get("rankings", [])
            if int(row.get("horizon", 0)) == horizon
        ],
        height=240,
    )