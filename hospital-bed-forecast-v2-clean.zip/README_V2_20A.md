# V2-20A — Automatic Evaluation Replay for Training Visualizations

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

## Status
CODE-READY. User runtime verification is still required before marking V2-20A COMPLETE.

## Goal
Create immutable row-level TEST evaluation evidence for every completed Training Run so Streamlit can render:

1. Train / Validation / Test Timeline
2. Actual vs Predicted on the Test Set
3. Residual over Time

Global and per-department metrics (MAE, RMSE, WAPE, R2, Bias, P90, Max Error, Within ±2, Underprediction metrics) already belong to each Training Run and therefore update automatically when the UI selects the latest run.

## Automatic workflow
From V2-20A onward, the persistent asynchronous Training Job completes only after:

Training -> Recommendation -> Evaluation Replay -> Job COMPLETED

Evaluation Replay reconstructs the historical holdout evaluation model from the stored Training Run contract. It never uses the ALL_MATURE Production artifact to predict the historical Test Set.

## Retry behavior
If Training and Recommendation have already completed but Evaluation Replay fails, the API Training Job is FAILED. A retry creates a new orchestration job. V2-14 returns ALREADY_COMPLETED, V2-15 returns ALREADY_RECOMMENDED, and only Evaluation Replay is retried.

A legacy COMPLETED API job is no longer reused when its Training Run lacks the complete 592-row evaluation evidence dataset. This allows the existing 2026-06-30 Training Run to be backfilled safely without retraining the scientific model.

## SQL evidence
Migration 009 creates `dbo.model_evaluation_predictions`.

Expected contract for the verified bootstrap Training Run:

- 8 candidates
- 74 TEST rows per candidate
- 37 TEST rows per department per candidate
- 592 rows total
- target_date 2026-05-25 through 2026-06-30
- residual = actual - predicted
- replay MAE must reproduce registry MAE within the configured absolute tolerance before any rows are committed

## Safety boundaries
V2-20A does not:

- create a new Training Run during replay
- change Production models
- promote or rollback models
- alter Official Forecasts
- change Daily Model Locks
- fabricate Actual data

## Manual verifier
After migration and replay/runtime backfill are complete:

```powershell
.\.venv\Scripts\python.exe -m scripts.verify_v2_20a
```

Expected final line:

`V2-20A VERIFY: PASS`
```

## Checkpoint command

Chỉ chạy test ở checkpoint đầu tiên; chưa apply migration và chưa chạy replay.

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

Expected: `119 passed` nếu chưa copy V2-20 Streamlit; `143 passed` nếu đã có 24 Streamlit tests.
