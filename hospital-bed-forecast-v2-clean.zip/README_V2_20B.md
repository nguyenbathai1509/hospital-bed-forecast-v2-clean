# V2-20B — Training Visualization API + Streamlit Integration

> Tài liệu lịch sử của giai đoạn này, không phải hướng dẫn vận hành hiện hành. Mốc ngày, số dòng và giới hạn bên dưới có thể đã thay đổi. Để sử dụng phiên bản hiện tại, xem [hướng dẫn Windows](docs/WINDOWS_QUICKSTART.md) và [quy trình vận hành](docs/OPERATIONS.md).

## Status
CODE-READY. Reference regression: 152 passed.

## Goal
Expose immutable V2-20A evaluation evidence through a read-only FastAPI endpoint and render a Streamlit Training Results page with five automatically updating visualizations:

1. Metric comparison across RF / XGBoost / SVR / LSTM (MAE, RMSE, WAPE, R2, Bias, P90, Max Error, Within ±2, Underprediction metrics)
2. Train / Validation / Test Timeline
3. Actual vs Predicted — Test Set
4. Residual over Time
5. Per-department metric comparison / detailed metric table

## Read-only API
`GET /training/evaluation/{run_id}` with query parameters:
- `horizon=1|3`
- `model_family=RF|XGBOOST|SVR|LSTM`
- optional `department_id`

The endpoint reads only `dbo.training_runs` and `dbo.model_evaluation_predictions`. It never trains or mutates Production/Official state.

## Automatic update contract
Training Job completion remains:

Training -> Recommendation -> Evaluation Replay -> COMPLETED

The Streamlit page selects the newest COMPLETED Training Run by default. Therefore a future successful Training Run automatically becomes the default chart dataset while historic runs remain selectable.

## Safety
- Streamlit calls FastAPI only.
- No SQL access from Streamlit.
- No hard-coded model metrics or chart predictions.
- Test predictions come from V2-20A immutable evaluation evidence, not Production artifacts.
